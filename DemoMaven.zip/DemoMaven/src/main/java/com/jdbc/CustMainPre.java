package com.jdbc;

public class CustMainPre {

	public static void main(String[] args) throws Exception{
		CustomerPreState cp=new CustomerPreState();
		//cp.InsertData();
		//cp.UpdateData();
		//cp.DeleteData();
		cp.getalldata();

	}

}
