package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomerPreState {
	public void InsertData() throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/batch204", "root", "root");
		PreparedStatement ps = c.prepareStatement("insert into customer(id,name,city)values(?,?,?)");
		ps.setInt(1, 3);
		ps.setString(2, "Sonali");
		ps.setString(3, "Nanded");
		ps.executeUpdate();
		System.out.println("data is inserted successfully");
		c.close();
	}

	public void UpdateData() throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/batch204", "root", "root");
		PreparedStatement ps = c.prepareStatement("update Customer set name=? where id=?");
		ps.setString(1, "poonam");
		ps.setInt(2, 3);
		ps.executeUpdate();
		System.out.println("data is updated successfully");

	}

	public void DeleteData() throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/batch204", "root", "root");
		PreparedStatement ps = c.prepareStatement("delete from customer where id=?");
		ps.setInt(1, 2);
		ps.executeUpdate();
		System.out.println("data is deleted succesfully");
		c.close();
	}
	public void getalldata()throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c= DriverManager.getConnection("jdbc:mysql://localhost:3306/batch204","root","root");
		PreparedStatement ps= c.prepareStatement("select * from customer");
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" |"+rs.getString(2)+"| "+rs.getString(3));
		//rs.close();
		}
	}

}
