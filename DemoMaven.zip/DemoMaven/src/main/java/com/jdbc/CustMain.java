package com.jdbc;

public class CustMain {

	public static void main(String[] args)throws Exception {
		CustomerStatement cs=new CustomerStatement();
		//cs.InsertData();
		//cs.UpdateData();
		//cs.DeleteData();
		cs.Getalldata();

	}

}
